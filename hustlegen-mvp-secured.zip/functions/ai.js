export default async (req, context) => {
  try {
    const body = await req.json();
    const { system, user } = body || {};
    const apiKey = process.env.OPENAI_API_KEY;
    const model = process.env.OPENAI_MODEL || "gpt-4o-mini";
    if (!apiKey) return new Response("Missing OPENAI_API_KEY", { status: 500 });
    const resp = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model, input: [
        { role: "system", content: system || "You are HustleGen." },
        { role: "user", content: user || "Say hello" }
      ] })
    });
    if (!resp.ok) return new Response(await resp.text(), { status: resp.status });
    const data = await resp.json();
    const output = data.output_text || "No output";
    return Response.json({ ok: true, output });
  } catch (e) {
    return new Response(String(e?.message || e), { status: 500 });
  }
}