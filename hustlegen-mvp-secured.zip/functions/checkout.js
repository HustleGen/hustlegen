export default async (req, context) => {
  try {
    const { tier } = await req.json();
    const key = process.env.STRIPE_SECRET_KEY;
    if (!key) return Response.json({ error: "Missing STRIPE_SECRET_KEY" }, { status: 500 });
    const priceMap = {
      basic: process.env.PRICE_BASIC,
      pro: process.env.PRICE_PRO,
      elite: process.env.PRICE_ELITE
    };
    const price = priceMap[tier];
    if (!price) return Response.json({ error: "Missing price id" }, { status: 400 });
    const res = await fetch("https://api.stripe.com/v1/checkout/sessions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        mode: "subscription",
        "line_items[0][price]": price,
        "line_items[0][quantity]": "1",
        success_url: "https://hustlegen.net/app?success=true",
        cancel_url: "https://hustlegen.net/app?canceled=true"
      })
    });
    const data = await res.json();
    if (data?.url) return Response.json({ url: data.url });
    return Response.json({ data });
  } catch (e) {
    return Response.json({ error: String(e?.message || e) }, { status: 500 });
  }
}