export default async (request: Request, context: any) => {
  const ip = context.ip || request.headers.get("x-forwarded-for") || "unknown";
  const url = new URL(request.url);
  const WINDOW_MS = 60_000;
  const MAX = Number(Deno.env.get("RL_MAX_PER_MIN") || "60");
  const key = `${Math.floor(Date.now() / WINDOW_MS)}:${ip}`;
  // @ts-ignore
  const store: Map<string, number> = (globalThis as any).__RL_STORE || ((globalThis as any).__RL_STORE = new Map());
  const count = (store.get(key) ?? 0) + 1;
  store.set(key, count);
  if (count > MAX) return new Response("Too many requests", { status: 429 });
  return context.next();
};